<footer class="text-center mt-5 p-3 bg-light text-muted border-top">
  <small>&copy; <?= date('Y') ?> Fachri Motorin - Hak Cipta Dilindungi.</small>
</footer>
</body>
</html>
