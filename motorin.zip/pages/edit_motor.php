<?php
include '../includes/db.php';
session_start();
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM motor WHERE id=$id")->fetch_assoc();
$merk = $conn->query("SELECT * FROM merk");

if (isset($_POST['update'])) {
  $nama = $_POST['nama'];
  $merk_id = $_POST['merk'];
  $harga = $_POST['harga'];
  $stok = $_POST['stok'];

  $conn->query("UPDATE motor SET nama_motor='$nama', merk_id=$merk_id, harga=$harga, stok=$stok WHERE id=$id");
  header("Location: data_motor.php");
}
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-5">
  <h3>Edit Motor</h3>
  <form method="POST">
    <input type="text" name="nama" value="<?= $data['nama_motor'] ?>" class="form-control mb-2">
    <select name="merk" class="form-control mb-2">
      <?php while($m = $merk->fetch_assoc()): ?>
        <option value="<?= $m['id'] ?>" <?= $m['id'] == $data['merk_id'] ? 'selected' : '' ?>>
          <?= $m['nama_merk'] ?>
        </option>
      <?php endwhile; ?>
    </select>
    <input type="number" name="harga" value="<?= $data['harga'] ?>" class="form-control mb-2">
    <input type="number" name="stok" value="<?= $data['stok'] ?>" class="form-control mb-2">
    <button name="update" class="btn btn-primary">Update</button>
  </form>
</div>

<?php include '../includes/footer.php'; ?>
