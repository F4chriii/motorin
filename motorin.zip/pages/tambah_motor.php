<?php
include '../includes/db.php';
session_start();

if (isset($_POST['simpan'])) {
  $nama = $_POST['nama'];
  $nama_merk = $_POST['merk']; // teks input merk
  $harga = $_POST['harga'];
  $stok = $_POST['stok'];

  // Cek apakah merk sudah ada
  $cek = $conn->query("SELECT id FROM merk WHERE nama_merk = '$nama_merk'");
  if ($cek->num_rows > 0) {
    $merk_id = $cek->fetch_assoc()['id'];
  } else {
    $conn->query("INSERT INTO merk (nama_merk) VALUES ('$nama_merk')");
    $merk_id = $conn->insert_id;
  }

  // Upload gambar
  $gambar = $_FILES['gambar']['name'];
  $tmp = $_FILES['gambar']['tmp_name'];
  $upload_dir = "../assets/img/";

  if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
  }

  $target_file = $upload_dir . basename($gambar);
  move_uploaded_file($tmp, $target_file);

  // Simpan motor
  $conn->query("INSERT INTO motor (nama_motor, merk_id, harga, stok, gambar) 
                VALUES ('$nama', $merk_id, $harga, $stok, '$gambar')");

  header("Location: data_motor.php");
}
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-5">
  <h3>Tambah Motor</h3>
  <form method="POST" enctype="multipart/form-data">
    <input type="text" name="nama" placeholder="Nama Motor" required class="form-control mb-2">
    
    <input type="text" name="merk" placeholder="Merk Motor (contoh: Honda)" required class="form-control mb-2">
    
    <input type="number" name="harga" placeholder="Harga" required class="form-control mb-2">
    <input type="number" name="stok" placeholder="Stok" required class="form-control mb-2">

    <label for="gambar" class="form-label mt-2">Upload Gambar Motor:</label>
    <input type="file" name="gambar" required class="form-control mb-3">

    <button name="simpan" class="btn btn-success w-100">Simpan</button>
  </form>
</div>

<?php include '../includes/footer.php'; ?>
