<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
}
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-5">
  <h2>Dashboard</h2>
  <p>Selamat datang, <?= $_SESSION['username'] ?>!</p>
  <div class="row">
    <div class="col-md-3"><a href="data_motor.php" class="btn btn-dark w-100">Kelola Motor</a></div>
    <div class="col-md-3"><a href="users.php" class="btn btn-secondary w-100">Data Pengguna</a></div>
    <div class="col-md-3"><a href="search.php" class="btn btn-warning w-100">Cari Motor</a></div>
    <div class="col-md-3"><a href="../logout.php" class="btn btn-danger w-100">Logout</a></div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
