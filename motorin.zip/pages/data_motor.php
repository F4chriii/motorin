<?php
include '../includes/db.php';
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
}

// Ambil data motor + merk + gambar
$motor = $conn->query("SELECT m.id, m.nama_motor, merk.nama_merk, m.harga, m.stok, m.gambar 
                       FROM motor m 
                       JOIN merk ON m.merk_id = merk.id");
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-5">
  <h3 class="mb-4">📋 Data Motor</h3>
  <a href="tambah_motor.php" class="btn btn-primary mb-3">+ Tambah Motor</a>
  <div class="table-responsive">
    <table class="table table-bordered align-middle text-center">
      <thead class="table-dark">
        <tr>
          <th>Gambar</th>
          <th>Nama</th>
          <th>Merk</th>
          <th>Harga</th>
          <th>Stok</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $motor->fetch_assoc()): ?>
          <tr>
            <td>
              <img src="../assets/img/<?= $row['gambar'] ?>" 
                   width="100" height="70" 
                   style="object-fit: cover; border-radius: 8px;">
            </td>
            <td><?= $row['nama_motor'] ?></td>
            <td><?= $row['nama_merk'] ?></td>
            <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
            <td><?= $row['stok'] ?></td>
            <td>
              <a href="edit_motor.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning mb-1">Edit</a>
              <a href="hapus_motor.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus data ini?')">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
