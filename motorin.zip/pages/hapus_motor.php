<?php
include '../includes/db.php';
session_start();
$id = $_GET['id'];
$conn->query("DELETE FROM motor WHERE id=$id");
header("Location: data_motor.php");
?>
