<?php
include '../includes/db.php';
session_start();

$keyword = isset($_GET['q']) ? $_GET['q'] : '';
$result = $conn->query("SELECT m.*, merk.nama_merk FROM motor m JOIN merk ON m.merk_id = merk.id WHERE nama_motor LIKE '%$keyword%'");
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-5">
  <h3>Cari Motor</h3>
  <form method="GET" class="mb-3">
    <input type="text" name="q" value="<?= $keyword ?>" class="form-control" placeholder="Cari nama motor...">
  </form>

  <?php if ($result->num_rows > 0): ?>
    <table class="table table-bordered mt-3">
      <thead><tr><th>Nama</th><th>Merk</th><th>Harga</th><th>Stok</th></tr></thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= $row['nama_motor'] ?></td>
          <td><?= $row['nama_merk'] ?></td>
          <td><?= number_format($row['harga']) ?></td>
          <td><?= $row['stok'] ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>Tidak ada hasil ditemukan.</p>
  <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
