<?php
include '../includes/db.php';
session_start();
$data = $conn->query("SELECT * FROM users");
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-5">
  <h3>Data Pengguna</h3>
  <table class="table table-bordered">
    <thead><tr><th>Username</th><th>Nama Lengkap</th></tr></thead>
    <tbody>
      <?php while($u = $data->fetch_assoc()): ?>
        <tr>
          <td><?= $u['username'] ?></td>
          <td><?= $u['nama_lengkap'] ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php include '../includes/footer.php'; ?>
