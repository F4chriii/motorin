<?php
session_start();
if (isset($_SESSION['login'])) {
    header("Location: pages/dashboard.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Motorin - Jual Beli Motor</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #1e3c72, #2a5298);
      color: white;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .card {
      border-radius: 16px;
      padding: 30px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }
  </style>
</head>
<body>
  <div class="card text-center bg-light text-dark">
    <h1 class="mb-3">Fachri Motorin</h1>
    <p class="lead">Website Penjualan Motor</p>
    <a href="login.php" class="btn btn-primary w-100 mb-2">Masuk</a>
    <a href="register.php" class="btn btn-outline-primary w-100">Daftar</a>
  </div>
</body>
</html>
